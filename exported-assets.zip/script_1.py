# First, let's create the core model training framework with all six model types
import numpy as np
import pandas as pd
import pickle
import os
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score, accuracy_score, brier_score_loss
from sklearn.calibration import IsotonicRegression
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# Create the main model training class
model_training_code = '''
import pandas as pd
import numpy as np
import pickle
import os
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score, accuracy_score, brier_score_loss, log_loss
from sklearn.calibration import IsotonicRegression
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import lightgbm as lgb
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

class ExplainableCreditScoringModel:
    """
    Comprehensive model training framework for explainable credit scoring
    Supporting all model types from the research paper
    """
    
    def __init__(self, random_state=42):
        self.random_state = random_state
        self.models = {}
        self.calibrators = {}
        self.scalers = {}
        self.feature_names = None
        self.performance_metrics = {}
        
    def define_model_configs(self):
        """Define hyperparameter grids for all model types"""
        return {
            'logistic_regression': {
                'model': LogisticRegression,
                'params': {
                    'C': [0.001, 0.01, 0.1, 1.0, 10.0],
                    'penalty': ['l1', 'l2', 'elasticnet'],
                    'solver': ['liblinear', 'saga'],
                    'random_state': [self.random_state],
                    'max_iter': [1000]
                }
            },
            'decision_tree': {
                'model': DecisionTreeClassifier,
                'params': {
                    'max_depth': [3, 5, 7, 10, None],
                    'min_samples_split': [100, 200, 500],
                    'min_samples_leaf': [50, 100, 200],
                    'random_state': [self.random_state]
                }
            },
            'random_forest': {
                'model': RandomForestClassifier,
                'params': {
                    'n_estimators': [100, 200, 500],
                    'max_depth': [10, 20, None],
                    'min_samples_split': [100, 200],
                    'min_samples_leaf': [50, 100],
                    'random_state': [self.random_state]
                }
            },
            'xgboost': {
                'model': xgb.XGBClassifier,
                'params': {
                    'max_depth': [3, 6, 9],
                    'learning_rate': [0.01, 0.1, 0.2],
                    'n_estimators': [100, 300, 500],
                    'subsample': [0.8, 1.0],
                    'colsample_bytree': [0.8, 1.0],
                    'random_state': [self.random_state],
                    'eval_metric': ['logloss'],
                    'use_label_encoder': [False]
                }
            },
            'lightgbm': {
                'model': lgb.LGBMClassifier,
                'params': {
                    'num_leaves': [31, 63, 127],
                    'learning_rate': [0.01, 0.1, 0.2],
                    'n_estimators': [100, 300, 500],
                    'subsample': [0.8, 1.0],
                    'colsample_bytree': [0.8, 1.0],
                    'random_state': [self.random_state],
                    'verbosity': [-1]
                }
            },
            'neural_network': {
                'model': MLPClassifier,
                'params': {
                    'hidden_layer_sizes': [(64,), (128,), (64, 32), (128, 64)],
                    'alpha': [0.001, 0.01, 0.1],
                    'learning_rate_init': [0.001, 0.01],
                    'max_iter': [500],
                    'random_state': [self.random_state]
                }
            }
        }
    
    def train_model(self, X_train, y_train, model_type='xgboost', cv_folds=3):
        """
        Train a specific model type with hyperparameter optimization
        """
        print(f"Training {model_type} model...")
        
        configs = self.define_model_configs()
        if model_type not in configs:
            raise ValueError(f"Model type {model_type} not supported")
        
        model_config = configs[model_type]
        base_model = model_config['model']()
        param_grid = model_config['params']
        
        # For neural networks, scale the features
        if model_type == 'neural_network':
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            self.scalers[model_type] = scaler
        else:
            X_train_scaled = X_train
            
        # Stratified CV with class balancing
        cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=self.random_state)
        
        # Grid search with AUC scoring
        grid_search = GridSearchCV(
            estimator=base_model,
            param_grid=param_grid,
            scoring='roc_auc',
            cv=cv,
            n_jobs=-1,
            verbose=0
        )
        
        # Handle class imbalance
        class_weights = self._calculate_class_weights(y_train)
        if hasattr(base_model, 'class_weight'):
            for params in param_grid:
                if isinstance(param_grid, list):
                    params['class_weight'] = [class_weights]
                else:
                    param_grid['class_weight'] = [class_weights]
        
        # Fit the model
        grid_search.fit(X_train_scaled, y_train)
        
        # Store the best model
        self.models[model_type] = grid_search.best_estimator_
        
        # Train calibrator
        self._fit_calibrator(X_train_scaled, y_train, model_type)
        
        print(f"{model_type} training complete. Best AUC: {grid_search.best_score_:.4f}")
        return grid_search.best_estimator_, grid_search.best_score_
    
    def _calculate_class_weights(self, y):
        """Calculate inverse prevalence class weights"""
        classes, counts = np.unique(y, return_counts=True)
        total = len(y)
        weights = {cls: total / (len(classes) * count) for cls, count in zip(classes, counts)}
        return weights
    
    def _fit_calibrator(self, X_train, y_train, model_type):
        """Fit isotonic regression calibrator"""
        model = self.models[model_type]
        
        # Get uncalibrated probabilities using cross-validation to avoid overfitting
        cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=self.random_state)
        uncalibrated_probs = np.zeros(len(y_train))
        
        for train_idx, val_idx in cv.split(X_train, y_train):
            X_tr, X_val = X_train[train_idx], X_train[val_idx]
            y_tr, y_val = y_train[train_idx], y_train[val_idx]
            
            # Clone and fit model on fold
            fold_model = type(model)(**model.get_params())
            fold_model.fit(X_tr, y_tr)
            
            # Get probabilities for validation set
            if hasattr(fold_model, 'predict_proba'):
                uncalibrated_probs[val_idx] = fold_model.predict_proba(X_val)[:, 1]
            else:
                uncalibrated_probs[val_idx] = fold_model.decision_function(X_val)
        
        # Fit isotonic regression
        calibrator = IsotonicRegression(out_of_bounds='clip')
        calibrator.fit(uncalibrated_probs, y_train)
        self.calibrators[model_type] = calibrator
    
    def predict_proba_calibrated(self, X, model_type):
        """Get calibrated probability predictions"""
        model = self.models[model_type]
        
        # Scale features if needed
        if model_type in self.scalers:
            X = self.scalers[model_type].transform(X)
        
        # Get uncalibrated probabilities
        if hasattr(model, 'predict_proba'):
            uncalibrated_probs = model.predict_proba(X)[:, 1]
        else:
            uncalibrated_probs = model.decision_function(X)
        
        # Apply calibration
        calibrator = self.calibrators[model_type]
        calibrated_probs = calibrator.transform(uncalibrated_probs)
        
        return calibrated_probs
    
    def evaluate_model(self, X_test, y_test, model_type):
        """Comprehensive model evaluation"""
        # Get predictions
        y_pred_proba = self.predict_proba_calibrated(X_test, model_type)
        y_pred = (y_pred_proba >= 0.5).astype(int)
        
        # Calculate metrics
        metrics = {
            'auc': roc_auc_score(y_test, y_pred_proba),
            'accuracy': accuracy_score(y_test, y_pred),
            'brier_score': brier_score_loss(y_test, y_pred_proba),
            'log_loss': log_loss(y_test, y_pred_proba)
        }
        
        # Calibration metrics
        metrics.update(self._calculate_calibration_metrics(y_test, y_pred_proba))
        
        self.performance_metrics[model_type] = metrics
        return metrics
    
    def _calculate_calibration_metrics(self, y_true, y_prob, n_bins=10):
        """Calculate detailed calibration metrics"""
        # Create bins
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        ece = 0  # Expected Calibration Error
        mce = 0  # Maximum Calibration Error
        
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            # Get instances in this bin
            in_bin = (y_prob > bin_lower) & (y_prob <= bin_upper)
            prop_in_bin = in_bin.sum() / len(y_prob)
            
            if prop_in_bin > 0:
                accuracy_in_bin = y_true[in_bin].mean()
                avg_confidence_in_bin = y_prob[in_bin].mean()
                
                ece += np.abs(avg_confidence_in_bin - accuracy_in_bin) * prop_in_bin
                mce = max(mce, np.abs(avg_confidence_in_bin - accuracy_in_bin))
        
        return {'ece': ece, 'mce': mce}
    
    def train_all_models(self, X_train, y_train, X_test, y_test):
        """Train all model types and return performance comparison"""
        self.feature_names = X_train.columns.tolist() if hasattr(X_train, 'columns') else None
        
        results = {}
        model_types = ['logistic_regression', 'decision_tree', 'random_forest', 
                      'xgboost', 'lightgbm', 'neural_network']
        
        for model_type in model_types:
            try:
                print(f"\\n=== Training {model_type.upper()} ===")
                
                # Train model
                model, cv_score = self.train_model(X_train, y_train, model_type)
                
                # Evaluate on test set
                test_metrics = self.evaluate_model(X_test, y_test, model_type)
                
                results[model_type] = {
                    'cv_score': cv_score,
                    'test_metrics': test_metrics,
                    'model': model
                }
                
                print(f"{model_type} - Test AUC: {test_metrics['auc']:.4f}, "
                      f"Brier Score: {test_metrics['brier_score']:.4f}")
                
            except Exception as e:
                print(f"Error training {model_type}: {str(e)}")
                results[model_type] = {'error': str(e)}
        
        return results
    
    def save_models(self, output_dir, dataset_name):
        """Save all trained models and results"""
        os.makedirs(output_dir, exist_ok=True)
        
        # Save models
        models_path = os.path.join(output_dir, f"{dataset_name}_models.pkl")
        with open(models_path, 'wb') as f:
            pickle.dump({
                'models': self.models,
                'calibrators': self.calibrators,
                'scalers': self.scalers,
                'feature_names': self.feature_names,
                'performance_metrics': self.performance_metrics
            }, f)
        
        print(f"Models saved to {models_path}")
        
        # Save performance summary as CSV
        perf_df = pd.DataFrame(self.performance_metrics).T
        perf_path = os.path.join(output_dir, f"{dataset_name}_performance_summary.csv")
        perf_df.to_csv(perf_path)
        print(f"Performance summary saved to {perf_path}")
        
        return models_path, perf_path
'''

# Save the main model training framework
with open('explainable_credit_scoring_model.py', 'w') as f:
    f.write(model_training_code)

print("✅ Created explainable_credit_scoring_model.py - Main model training framework")