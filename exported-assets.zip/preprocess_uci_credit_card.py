
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import warnings
warnings.filterwarnings('ignore')

def preprocess_uci_credit_card(file_path, random_state=42):
    """
    Preprocess UCI Credit Card Default dataset
    Based on the methodology from the research paper
    """
    print("Starting UCI Credit Card preprocessing...")

    # Load data
    df = pd.read_csv(file_path)
    print(f"Loaded dataset with shape: {df.shape}")

    # Examine columns - UCI dataset typically has these columns:
    # ID, LIMIT_BAL, SEX, EDUCATION, MARRIAGE, AGE, PAY_0 to PAY_6, BILL_AMT1 to BILL_AMT6, PAY_AMT1 to PAY_AMT6, default.payment.next.month

    # Rename target column for consistency
    target_columns = ['default.payment.next.month', 'default payment next month', 'TARGET', 'target']
    target_col = None
    for col in target_columns:
        if col in df.columns:
            target_col = col
            break

    if target_col is None:
        # Try to find target column by checking last column
        target_col = df.columns[-1]
        print(f"Using last column as target: {target_col}")

    # Rename target column
    if target_col != 'TARGET':
        df = df.rename(columns={target_col: 'TARGET'})

    # Remove ID column if present
    id_columns = ['ID', 'id', 'Id']
    for id_col in id_columns:
        if id_col in df.columns:
            df = df.drop(columns=[id_col])
            print(f"Dropped ID column: {id_col}")

    print(f"Dataset columns: {df.columns.tolist()}")
    print(f"Target distribution: {df['TARGET'].value_counts()}")

    # Separate features and target
    y = df['TARGET']
    X = df.drop(columns=['TARGET'])

    # Feature engineering based on domain knowledge
    print("Performing feature engineering...")

    # Create age groups if AGE column exists
    if 'AGE' in X.columns:
        X['AGE_GROUP_young'] = (X['AGE'] < 30).astype(int)
        X['AGE_GROUP_middle'] = ((X['AGE'] >= 30) & (X['AGE'] < 50)).astype(int)
        X['AGE_GROUP_senior'] = (X['AGE'] >= 50).astype(int)

    # Handle categorical variables
    categorical_features = []

    # Sex (1=male, 2=female -> convert to binary)
    if 'SEX' in X.columns:
        X['SEX_male'] = (X['SEX'] == 1).astype(int)
        X['SEX_female'] = (X['SEX'] == 2).astype(int)
        categorical_features.extend(['SEX_male', 'SEX_female'])
        X = X.drop(columns=['SEX'])

    # Education
    if 'EDUCATION' in X.columns:
        # Create education level indicators
        X['EDUCATION_graduate'] = (X['EDUCATION'] == 1).astype(int)  # Graduate school
        X['EDUCATION_university'] = (X['EDUCATION'] == 2).astype(int)  # University
        X['EDUCATION_high_school'] = (X['EDUCATION'] == 3).astype(int)  # High school
        X['EDUCATION_others'] = (X['EDUCATION'].isin([4, 5, 6, 0])).astype(int)  # Others/Unknown
        categorical_features.extend(['EDUCATION_graduate', 'EDUCATION_university', 
                                   'EDUCATION_high_school', 'EDUCATION_others'])
        X = X.drop(columns=['EDUCATION'])

    # Marriage
    if 'MARRIAGE' in X.columns:
        X['MARRIAGE_married'] = (X['MARRIAGE'] == 1).astype(int)
        X['MARRIAGE_single'] = (X['MARRIAGE'] == 2).astype(int)
        X['MARRIAGE_divorced'] = (X['MARRIAGE'] == 3).astype(int)
        X['MARRIAGE_others'] = (~X['MARRIAGE'].isin([1, 2, 3])).astype(int)
        categorical_features.extend(['MARRIAGE_married', 'MARRIAGE_single', 
                                   'MARRIAGE_divorced', 'MARRIAGE_others'])
        X = X.drop(columns=['MARRIAGE'])

    # Create payment pattern features
    pay_columns = [col for col in X.columns if col.startswith('PAY_')]
    if pay_columns:
        # Count of late payments
        pay_df = X[pay_columns]
        X['late_payment_count'] = (pay_df > 0).sum(axis=1)
        X['max_delay_months'] = pay_df.max(axis=1)
        X['avg_delay_months'] = pay_df.mean(axis=1)

    # Create utilization ratios
    bill_columns = [col for col in X.columns if col.startswith('BILL_AMT')]
    if bill_columns and 'LIMIT_BAL' in X.columns:
        for bill_col in bill_columns:
            util_col = bill_col.replace('BILL_AMT', 'UTILIZATION_')
            X[util_col] = X[bill_col] / (X['LIMIT_BAL'] + 1)  # +1 to avoid division by zero

    # Identify numerical features (everything not categorical)
    numerical_features = [col for col in X.columns if col not in categorical_features]

    print(f"Numerical features: {len(numerical_features)}")
    print(f"Categorical features: {len(categorical_features)}")

    # Create preprocessing pipelines
    numerical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='constant', fill_value=0))
    ])

    # Create stratified folds
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
    folds = []

    print("Creating cross-validation folds...")

    for fold_idx, (train_idx, val_idx) in enumerate(skf.split(X, y)):
        print(f"Processing fold {fold_idx + 1}/5...")

        X_train_fold = X.iloc[train_idx].copy()
        y_train_fold = y.iloc[train_idx].copy()
        X_val_fold = X.iloc[val_idx].copy()
        y_val_fold = y.iloc[val_idx].copy()

        # Create preprocessor for this fold
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numerical_transformer, numerical_features),
                ('cat', categorical_transformer, categorical_features)
            ])

        # Fit on train, transform both train and validation
        X_train_processed = preprocessor.fit_transform(X_train_fold)
        X_val_processed = preprocessor.transform(X_val_fold)

        # Create feature names
        num_feature_names = numerical_features
        cat_feature_names = categorical_features
        all_feature_names = num_feature_names + cat_feature_names

        # Convert to DataFrames
        X_train_processed = pd.DataFrame(
            X_train_processed, 
            columns=all_feature_names, 
            index=X_train_fold.index
        )
        X_val_processed = pd.DataFrame(
            X_val_processed, 
            columns=all_feature_names, 
            index=X_val_fold.index
        )

        folds.append({
            'X_train': X_train_processed,
            'X_test': X_val_processed,  # Using 'X_test' for consistency with existing code
            'y_train': y_train_fold,
            'y_test': y_val_fold  # Using 'y_test' for consistency
        })

    print(f"UCI Credit Card preprocessing complete. Generated {len(folds)} folds.")
    print(f"Feature count: {len(all_feature_names)}")
    print(f"Sample sizes: {[len(fold['X_train']) for fold in folds]}")

    return folds, all_feature_names

if __name__ == "__main__":
    # Example usage
    input_path = "UCI_Credit_Card.csv"
    folds, feature_names = preprocess_uci_credit_card(input_path)

    print(f"\nPreprocessing Summary:")
    print(f"Number of folds: {len(folds)}")
    print(f"Number of features: {len(feature_names)}")
    print(f"Features: {feature_names[:10]}..." if len(feature_names) > 10 else f"Features: {feature_names}")
