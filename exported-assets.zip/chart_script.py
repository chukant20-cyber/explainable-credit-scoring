import plotly.graph_objects as go
import plotly.io as pio
import numpy as np

# Data for the flowchart with metrics
layers_data = [
    {
        "name": "Data Input", 
        "components": ["UCI Credit", "LendingClub", "Home Credit"], 
        "details": ["30K, 22% def", "887K, 6% def", "308K, 8% def"],
        "color": "#1FB8CD"
    },
    {
        "name": "Preprocessing", 
        "components": ["Feature Eng", "Missing Impute", "Cat Encoding", "5-Fold CV"], 
        "details": ["", "", "", ""],
        "color": "#DB4545"
    },
    {
        "name": "Model Training", 
        "components": ["Logistic Reg", "Decision Tree", "Random Forest", "XGBoost", "LightGBM", "Neural Net"], 
        "details": ["", "", "", "Primary", "", ""],
        "metrics": ["AUC: 0.89-0.92", "Brier: 0.12-0.15", "ECE: 0.02-0.03"],
        "color": "#2E8B57"
    },
    {
        "name": "Explainability", 
        "components": ["SHAP Tree", "SHAP Kernel", "LIME Local", "Stability"], 
        "details": ["", "", "", "1000 boots"],
        "metrics": ["Kendall τ: 0.93", "Stability: 94%"],
        "color": "#5D878F"
    },
    {
        "name": "Fairness Eval", 
        "components": ["Demog Parity", "Equal Odds", "Pred Parity", "Constraint"], 
        "details": ["", "", "", "Optim"],
        "metrics": ["Gap Red: 62%", "Cost Inc: 3.9%"],
        "color": "#D2BA4C"
    },
    {
        "name": "Statistical", 
        "components": ["H1: Model", "H2: Stability", "H3: Fairness", "H4: Alt Data"], 
        "details": ["Perf", "", "Constraints", "Value"],
        "color": "#B4413C"
    },
    {
        "name": "Output", 
        "components": ["Model Files", "Explain Data", "Fairness Res", "Reports", "Repro Code"], 
        "details": [".pkl", "", "", "Comprehen", ""],
        "color": "#964325"
    }
]

# Create figure
fig = go.Figure()

# Layout parameters
layer_height = 1.0
component_width = 0.8
layer_spacing = 1.5
y_positions = list(range(len(layers_data)-1, -1, -1))

# Add layer boxes and components
for i, layer in enumerate(layers_data):
    y_pos = y_positions[i]
    
    # Add main layer header
    fig.add_trace(go.Scatter(
        x=[0], y=[y_pos + 0.3],
        mode='markers+text',
        marker=dict(size=120, color=layer["color"], symbol='square'),
        text=layer["name"],
        textposition="middle center",
        textfont=dict(size=14, color='white'),
        showlegend=False,
        hoverinfo='skip'
    ))
    
    # Add components
    max_components = max(len(l["components"]) for l in layers_data)
    component_positions = np.linspace(-max_components/2 + 0.5, max_components/2 - 0.5, len(layer["components"]))
    
    for j, (comp, detail) in enumerate(zip(layer["components"], layer["details"])):
        x_pos = component_positions[j] * 0.6 + 2
        
        # Component box
        fig.add_trace(go.Scatter(
            x=[x_pos], y=[y_pos],
            mode='markers+text',
            marker=dict(size=80, color=layer["color"], symbol='square', opacity=0.7),
            text=comp,
            textposition="middle center",
            textfont=dict(size=10),
            showlegend=False,
            hoverinfo='skip'
        ))
        
        # Detail text if exists
        if detail:
            fig.add_trace(go.Scatter(
                x=[x_pos], y=[y_pos - 0.15],
                mode='text',
                text=detail,
                textposition="middle center",
                textfont=dict(size=8, color='gray'),
                showlegend=False,
                hoverinfo='skip'
            ))
    
    # Add metrics if they exist
    if "metrics" in layer:
        for k, metric in enumerate(layer["metrics"]):
            fig.add_trace(go.Scatter(
                x=[4.5], y=[y_pos + 0.2 - k*0.15],
                mode='text',
                text=metric,
                textposition="middle left",
                textfont=dict(size=9, color='darkblue'),
                showlegend=False,
                hoverinfo='skip'
            ))

# Add flow arrows between layers
for i in range(len(layers_data) - 1):
    y_start = y_positions[i] - 0.2
    y_end = y_positions[i+1] + 0.2
    
    fig.add_annotation(
        x=1, y=y_start,
        ax=1, ay=y_end,
        xref="x", yref="y",
        axref="x", ayref="y",
        arrowhead=2,
        arrowsize=1,
        arrowwidth=3,
        arrowcolor="gray",
        showarrow=True
    )

# Update layout
fig.update_layout(
    title="Credit Score Framework Architecture",
    xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-1, 6]),
    yaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-0.5, len(layers_data)-0.5]),
    plot_bgcolor='white',
    showlegend=False
)

fig.update_traces(cliponaxis=False)

# Save as both PNG and SVG
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")

fig.show()