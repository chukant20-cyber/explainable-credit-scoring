
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import warnings
warnings.filterwarnings('ignore')

def preprocess_lending_club(file_path, random_state=42):
    """
    Preprocess LendingClub loan data
    Based on the methodology from the research paper
    """
    print("Starting LendingClub preprocessing...")

    # Load data - LendingClub files can be large, so we'll process in chunks if needed
    try:
        df = pd.read_csv(file_path, low_memory=False)
    except Exception as e:
        print(f"Error loading full file: {e}")
        print("Attempting to load with chunking...")
        # Load in smaller chunks if the file is too large
        chunk_size = 50000
        chunks = []
        for chunk in pd.read_csv(file_path, chunksize=chunk_size, low_memory=False):
            chunks.append(chunk)
            if len(chunks) * chunk_size >= 200000:  # Limit to ~200K rows for memory
                break
        df = pd.concat(chunks, ignore_index=True)

    print(f"Loaded dataset with shape: {df.shape}")
    print(f"Columns: {df.columns.tolist()[:20]}...")  # Show first 20 columns

    # Define target variable mapping
    # LendingClub loan_status values indicate loan outcome
    target_mapping = {
        'loan_status': {
            'charged_off': 1,
            'default': 1,
            'charged off': 1,
            'fully paid': 0,
            'paid': 0,
            'current': 0,  # Assuming current loans are performing
            'in grace period': 0,
            'late (31-120 days)': 1,
            'late (16-30 days)': 0  # Minor lateness, not default
        }
    }

    # Find target column
    target_col = None
    for col in ['loan_status', 'status', 'TARGET', 'target']:
        if col in df.columns:
            target_col = col
            break

    if target_col is None:
        raise ValueError("Could not find target column in LendingClub data")

    print(f"Using target column: {target_col}")
    print(f"Target value counts:\n{df[target_col].value_counts()}")

    # Create binary target
    df['TARGET'] = df[target_col].str.lower().map(
        lambda x: target_mapping['loan_status'].get(x, np.nan)
    )

    # Remove rows with missing target
    initial_size = len(df)
    df = df.dropna(subset=['TARGET'])
    print(f"Removed {initial_size - len(df)} rows with missing target")

    print(f"Final target distribution:\n{df['TARGET'].value_counts()}")
    print(f"Default rate: {df['TARGET'].mean():.1%}")

    # Drop irrelevant columns
    cols_to_drop = [
        target_col, 'id', 'member_id', 'url', 'desc', 'title', 'zip_code',
        'addr_state', 'last_pymnt_d', 'next_pymnt_d', 'last_credit_pull_d',
        'issue_d', 'earliest_cr_line', 'last_pymnt_amnt', 'recoveries',
        'collection_recovery_fee', 'policy_code', 'hardship_flag',
        'debt_settlement_flag'
    ]

    # Drop columns that exist
    existing_cols_to_drop = [col for col in cols_to_drop if col in df.columns]
    df = df.drop(columns=existing_cols_to_drop)
    print(f"Dropped {len(existing_cols_to_drop)} irrelevant columns")

    # Separate features and target
    y = df['TARGET']
    X = df.drop(columns=['TARGET'])

    print(f"Feature columns after cleanup: {len(X.columns)}")

    # Feature engineering
    print("Performing feature engineering...")

    # Create income groups for fairness analysis
    if 'annual_inc' in X.columns:
        X['income_low'] = (X['annual_inc'] <= 60000).astype(int)
        X['income_medium'] = ((X['annual_inc'] > 60000) & (X['annual_inc'] <= 120000)).astype(int)
        X['income_high'] = (X['annual_inc'] > 120000).astype(int)

    # Create DTI (Debt-to-Income) categories
    if 'dti' in X.columns:
        X['dti_low'] = (X['dti'] <= 10).astype(int)
        X['dti_medium'] = ((X['dti'] > 10) & (X['dti'] <= 20)).astype(int)
        X['dti_high'] = (X['dti'] > 20).astype(int)

    # Employment length categories
    if 'emp_length' in X.columns:
        # Handle employment length (typically in format "X years" or "< 1 year")
        def parse_emp_length(emp_len):
            if pd.isna(emp_len) or emp_len == 'n/a':
                return -1
            elif '< 1' in str(emp_len):
                return 0.5
            elif '10+' in str(emp_len):
                return 10
            else:
                # Extract number from string like "2 years"
                try:
                    return float(str(emp_len).split()[0])
                except:
                    return -1

        X['emp_length_numeric'] = X['emp_length'].apply(parse_emp_length)
        X['emp_length_short'] = (X['emp_length_numeric'] < 2).astype(int)
        X['emp_length_medium'] = ((X['emp_length_numeric'] >= 2) & (X['emp_length_numeric'] < 5)).astype(int)
        X['emp_length_long'] = (X['emp_length_numeric'] >= 5).astype(int)
        X['emp_length_missing'] = (X['emp_length_numeric'] == -1).astype(int)

    # Credit utilization ratio
    if 'revol_bal' in X.columns and 'revol_util' in X.columns:
        X['revol_util_high'] = (X['revol_util'] > 80).astype(int)
        X['revol_util_medium'] = ((X['revol_util'] > 30) & (X['revol_util'] <= 80)).astype(int)
        X['revol_util_low'] = (X['revol_util'] <= 30).astype(int)

    # Loan characteristics
    if 'loan_amnt' in X.columns and 'annual_inc' in X.columns:
        X['loan_to_income_ratio'] = X['loan_amnt'] / (X['annual_inc'] + 1)
        X['high_loan_ratio'] = (X['loan_to_income_ratio'] > 0.3).astype(int)

    # Identify column types
    numerical_columns = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_columns = X.select_dtypes(include=['object']).columns.tolist()

    print(f"Numerical columns: {len(numerical_columns)}")
    print(f"Categorical columns: {len(categorical_columns)}")

    # Handle high-cardinality categorical variables
    high_cardinality_threshold = 50
    high_cardinality_cols = []

    for col in categorical_columns:
        if X[col].nunique() > high_cardinality_threshold:
            high_cardinality_cols.append(col)
            print(f"High cardinality column {col}: {X[col].nunique()} unique values")

    # Remove high cardinality columns that are likely not useful
    X = X.drop(columns=high_cardinality_cols)
    categorical_columns = [col for col in categorical_columns if col not in high_cardinality_cols]

    # Update column lists
    numerical_columns = [col for col in numerical_columns if col in X.columns]
    categorical_columns = [col for col in categorical_columns if col in X.columns]

    print(f"Final feature count: {len(X.columns)}")
    print(f"Numerical: {len(numerical_columns)}, Categorical: {len(categorical_columns)}")

    # Create preprocessing pipelines
    numerical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', max_categories=20))
    ])

    # Create stratified folds
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
    folds = []

    print("Creating cross-validation folds...")

    # For very large datasets, take a sample for fold creation
    sample_size = min(100000, len(X))
    if len(X) > sample_size:
        print(f"Sampling {sample_size} records for fold creation...")
        sample_idx = np.random.choice(len(X), size=sample_size, replace=False)
        X_sample = X.iloc[sample_idx]
        y_sample = y.iloc[sample_idx]
    else:
        X_sample = X
        y_sample = y

    for fold_idx, (train_idx, val_idx) in enumerate(skf.split(X_sample, y_sample)):
        print(f"Processing fold {fold_idx + 1}/5...")

        X_train_fold = X_sample.iloc[train_idx].copy()
        y_train_fold = y_sample.iloc[train_idx].copy()
        X_val_fold = X_sample.iloc[val_idx].copy()
        y_val_fold = y_sample.iloc[val_idx].copy()

        # Create preprocessor for this fold
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numerical_transformer, numerical_columns),
                ('cat', categorical_transformer, categorical_columns)
            ])

        # Fit on train, transform both train and validation
        X_train_processed = preprocessor.fit_transform(X_train_fold)
        X_val_processed = preprocessor.transform(X_val_fold)

        # Create feature names
        num_feature_names = numerical_columns

        # Get categorical feature names from OneHotEncoder
        if categorical_columns:
            cat_feature_names = preprocessor.named_transformers_['cat']['onehot'].get_feature_names_out(categorical_columns)
            cat_feature_names = cat_feature_names.tolist()
        else:
            cat_feature_names = []

        all_feature_names = num_feature_names + cat_feature_names

        # Convert to DataFrames
        X_train_processed = pd.DataFrame(
            X_train_processed, 
            columns=all_feature_names, 
            index=X_train_fold.index
        )
        X_val_processed = pd.DataFrame(
            X_val_processed, 
            columns=all_feature_names, 
            index=X_val_fold.index
        )

        folds.append({
            'X_train': X_train_processed,
            'X_test': X_val_processed,
            'y_train': y_train_fold,
            'y_test': y_val_fold
        })

    print(f"LendingClub preprocessing complete. Generated {len(folds)} folds.")
    print(f"Feature count: {len(all_feature_names)}")
    print(f"Sample sizes: {[len(fold['X_train']) for fold in folds]}")

    return folds, all_feature_names

if __name__ == "__main__":
    # Example usage
    input_path = "loans_full_schema.csv"
    folds, feature_names = preprocess_lending_club(input_path)

    print(f"\nPreprocessing Summary:")
    print(f"Number of folds: {len(folds)}")
    print(f"Number of features: {len(feature_names)}")
    print(f"Sample features: {feature_names[:10]}..." if len(feature_names) > 10 else f"Features: {feature_names}")
