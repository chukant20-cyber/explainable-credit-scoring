
import pandas as pd
import numpy as np
import pickle
import os
import shap
import lime
import lime.lime_tabular
from sklearn.model_selection import train_test_split
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

class ExplanationGenerator:
    """
    Comprehensive explanation generation using SHAP and LIME
    Implements stability analysis and explanation validation
    """

    def __init__(self, random_state=42):
        self.random_state = random_state
        self.shap_explainers = {}
        self.lime_explainers = {}
        self.explanation_data = {}

    def load_trained_models(self, models_path):
        """Load pre-trained models and associated components"""
        print("Loading trained models...")

        with open(models_path, 'rb') as f:
            model_data = pickle.load(f)

        self.models = model_data['models']
        self.calibrators = model_data['calibrators']
        self.scalers = model_data.get('scalers', {})
        self.feature_names = model_data['feature_names']

        print(f"Loaded {len(self.models)} trained models")
        return list(self.models.keys())

    def setup_shap_explainers(self, X_background, model_types=None):
        """Initialize SHAP explainers for different model types"""
        if model_types is None:
            model_types = list(self.models.keys())

        print("Setting up SHAP explainers...")

        for model_type in model_types:
            if model_type not in self.models:
                print(f"Warning: {model_type} model not found, skipping...")
                continue

            model = self.models[model_type]

            # Handle different model types
            if model_type in ['xgboost', 'lightgbm', 'random_forest', 'decision_tree']:
                # Tree-based models use TreeExplainer
                self.shap_explainers[model_type] = shap.TreeExplainer(model)

            elif model_type == 'neural_network':
                # Neural networks use DeepExplainer with background data
                if model_type in self.scalers:
                    X_bg_scaled = self.scalers[model_type].transform(X_background)
                else:
                    X_bg_scaled = X_background

                # Create a wrapper function for neural network predictions
                def nn_predict(X):
                    return model.predict_proba(X)[:, 1:2]  # Return as 2D array

                self.shap_explainers[model_type] = shap.KernelExplainer(
                    nn_predict, X_bg_scaled[:100]  # Use smaller background for efficiency
                )

            else:
                # Linear models use LinearExplainer or KernelExplainer
                if model_type in self.scalers:
                    X_bg_scaled = self.scalers[model_type].transform(X_background)
                else:
                    X_bg_scaled = X_background

                def model_predict(X):
                    if hasattr(model, 'predict_proba'):
                        return model.predict_proba(X)[:, 1]
                    else:
                        return model.decision_function(X)

                self.shap_explainers[model_type] = shap.KernelExplainer(
                    model_predict, X_bg_scaled[:100]
                )

        print(f"SHAP explainers ready for: {list(self.shap_explainers.keys())}")

    def setup_lime_explainers(self, X_train, model_types=None):
        """Initialize LIME explainers"""
        if model_types is None:
            model_types = list(self.models.keys())

        print("Setting up LIME explainers...")

        # Convert to numpy array if pandas DataFrame
        if hasattr(X_train, 'values'):
            X_train_array = X_train.values
        else:
            X_train_array = X_train

        for model_type in model_types:
            if model_type not in self.models:
                continue

            model = self.models[model_type]

            # Create prediction function for LIME
            def lime_predict_fn(X):
                # Scale features if needed
                if model_type in self.scalers:
                    X_scaled = self.scalers[model_type].transform(X)
                else:
                    X_scaled = X

                # Get predictions
                if hasattr(model, 'predict_proba'):
                    return model.predict_proba(X_scaled)
                else:
                    # For models without predict_proba, create probability-like output
                    scores = model.decision_function(X_scaled)
                    # Convert to probabilities using sigmoid
                    probs_pos = 1 / (1 + np.exp(-scores))
                    probs = np.column_stack([1 - probs_pos, probs_pos])
                    return probs

            # Initialize LIME explainer
            self.lime_explainers[model_type] = lime.lime_tabular.LimeTabularExplainer(
                X_train_array,
                feature_names=self.feature_names,
                class_names=['No Default', 'Default'],
                mode='classification',
                discretize_continuous=True,
                random_state=self.random_state
            )

            # Store prediction function
            setattr(self.lime_explainers[model_type], 'predict_fn', lime_predict_fn)

        print(f"LIME explainers ready for: {list(self.lime_explainers.keys())}")

    def generate_shap_explanations(self, X_sample, model_type, max_evals=1000):
        """Generate SHAP explanations for a sample"""
        print(f"Generating SHAP explanations for {model_type}...")

        if model_type not in self.shap_explainers:
            print(f"SHAP explainer not found for {model_type}")
            return None

        explainer = self.shap_explainers[model_type]

        # Scale features if needed
        if model_type in self.scalers:
            X_sample_scaled = self.scalers[model_type].transform(X_sample)
        else:
            X_sample_scaled = X_sample

        try:
            # Generate SHAP values
            if hasattr(explainer, 'shap_values'):
                # Tree explainers
                shap_values = explainer.shap_values(X_sample_scaled)
                if isinstance(shap_values, list):
                    shap_values = shap_values[1]  # Take positive class
            else:
                # Other explainers
                shap_values = explainer(X_sample_scaled, max_evals=max_evals)
                if hasattr(shap_values, 'values'):
                    shap_values = shap_values.values

            # Store results
            self.explanation_data[f'{model_type}_shap'] = {
                'shap_values': shap_values,
                'X_sample': X_sample,
                'feature_names': self.feature_names,
                'base_value': getattr(explainer, 'expected_value', 0)
            }

            print(f"SHAP explanations generated for {len(X_sample)} samples")
            return shap_values

        except Exception as e:
            print(f"Error generating SHAP explanations for {model_type}: {e}")
            return None

    def generate_lime_explanations(self, X_sample, model_type, num_features=10, num_samples=5000):
        """Generate LIME explanations for a sample"""
        print(f"Generating LIME explanations for {model_type}...")

        if model_type not in self.lime_explainers:
            print(f"LIME explainer not found for {model_type}")
            return None

        explainer = self.lime_explainers[model_type]
        predict_fn = explainer.predict_fn

        # Convert to numpy array if needed
        if hasattr(X_sample, 'values'):
            X_sample_array = X_sample.values
        else:
            X_sample_array = X_sample

        lime_explanations = []
        lime_scores = []

        try:
            # Generate explanations for each instance
            for i in range(len(X_sample_array)):
                if i % 100 == 0:
                    print(f"Processing instance {i+1}/{len(X_sample_array)}")

                explanation = explainer.explain_instance(
                    X_sample_array[i], 
                    predict_fn,
                    num_features=num_features,
                    num_samples=num_samples
                )

                lime_explanations.append(explanation)

                # Extract feature importance scores
                feature_scores = dict(explanation.as_list())
                score_vector = np.zeros(len(self.feature_names))
                for feat_name, score in feature_scores.items():
                    if feat_name in self.feature_names:
                        feat_idx = self.feature_names.index(feat_name)
                        score_vector[feat_idx] = score

                lime_scores.append(score_vector)

            lime_scores = np.array(lime_scores)

            # Store results
            self.explanation_data[f'{model_type}_lime'] = {
                'lime_explanations': lime_explanations,
                'lime_scores': lime_scores,
                'X_sample': X_sample,
                'feature_names': self.feature_names
            }

            print(f"LIME explanations generated for {len(X_sample)} samples")
            return lime_explanations, lime_scores

        except Exception as e:
            print(f"Error generating LIME explanations for {model_type}: {e}")
            return None, None

    def analyze_explanation_stability(self, X_data, y_data, model_type, n_bootstrap=100):
        """
        Analyze stability of explanations across bootstrap samples
        Tests Hypothesis H2 from the research paper
        """
        print(f"\nAnalyzing explanation stability for {model_type}...")
        print(f"Running {n_bootstrap} bootstrap iterations...")

        if model_type not in self.models:
            print(f"Model {model_type} not found")
            return None

        stability_results = {
            'shap_kendall_taus': [],
            'lime_kendall_taus': [],
            'shap_feature_overlaps': [],
            'lime_feature_overlaps': [],
            'bootstrap_iteration': []
        }

        # Original explanations for comparison
        print("Generating baseline explanations...")
        sample_size = min(1000, len(X_data))  # Use manageable sample size
        sample_idx = np.random.choice(len(X_data), size=sample_size, replace=False)
        X_sample = X_data.iloc[sample_idx] if hasattr(X_data, 'iloc') else X_data[sample_idx]

        # Generate baseline SHAP explanations
        baseline_shap = self.generate_shap_explanations(X_sample, model_type)
        baseline_shap_importance = np.abs(baseline_shap).mean(axis=0) if baseline_shap is not None else None

        # Generate baseline LIME explanations (smaller sample for efficiency)
        lime_sample_size = min(100, len(X_sample))
        X_lime_sample = X_sample.iloc[:lime_sample_size] if hasattr(X_sample, 'iloc') else X_sample[:lime_sample_size]
        _, baseline_lime = self.generate_lime_explanations(X_lime_sample, model_type)
        baseline_lime_importance = np.abs(baseline_lime).mean(axis=0) if baseline_lime is not None else None

        # Bootstrap stability analysis
        for i in range(n_bootstrap):
            if (i + 1) % 20 == 0:
                print(f"Bootstrap iteration {i+1}/{n_bootstrap}")

            try:
                # Bootstrap sample
                bootstrap_idx = np.random.choice(len(X_data), size=len(X_data), replace=True)
                X_bootstrap = X_data.iloc[bootstrap_idx] if hasattr(X_data, 'iloc') else X_data[bootstrap_idx]
                y_bootstrap = y_data.iloc[bootstrap_idx] if hasattr(y_data, 'iloc') else y_data[bootstrap_idx]

                # Retrain model on bootstrap sample (simplified for efficiency)
                # In practice, you would retrain, but this is computationally intensive
                # For stability analysis, we'll use the same model with bootstrap data sample

                # Generate explanations on bootstrap sample
                boot_sample_idx = np.random.choice(len(X_bootstrap), size=sample_size, replace=False)
                X_boot_sample = X_bootstrap.iloc[boot_sample_idx] if hasattr(X_bootstrap, 'iloc') else X_bootstrap[boot_sample_idx]

                # SHAP on bootstrap
                boot_shap = self.generate_shap_explanations(X_boot_sample, model_type)
                if boot_shap is not None and baseline_shap_importance is not None:
                    boot_shap_importance = np.abs(boot_shap).mean(axis=0)

                    # Calculate Kendall's tau for feature importance ranking
                    tau, _ = stats.kendalltau(baseline_shap_importance, boot_shap_importance)
                    stability_results['shap_kendall_taus'].append(tau)

                    # Calculate top-k feature overlap
                    k = min(10, len(baseline_shap_importance))
                    baseline_top_k = set(np.argsort(baseline_shap_importance)[-k:])
                    boot_top_k = set(np.argsort(boot_shap_importance)[-k:])
                    overlap = len(baseline_top_k.intersection(boot_top_k)) / k
                    stability_results['shap_feature_overlaps'].append(overlap)

                # LIME on bootstrap (smaller sample)
                X_lime_boot_sample = X_boot_sample.iloc[:lime_sample_size] if hasattr(X_boot_sample, 'iloc') else X_boot_sample[:lime_sample_size]
                _, boot_lime = self.generate_lime_explanations(X_lime_boot_sample, model_type)
                if boot_lime is not None and baseline_lime_importance is not None:
                    boot_lime_importance = np.abs(boot_lime).mean(axis=0)

                    tau, _ = stats.kendalltau(baseline_lime_importance, boot_lime_importance)
                    stability_results['lime_kendall_taus'].append(tau)

                    k = min(10, len(baseline_lime_importance))
                    baseline_top_k = set(np.argsort(baseline_lime_importance)[-k:])
                    boot_top_k = set(np.argsort(boot_lime_importance)[-k:])
                    overlap = len(baseline_top_k.intersection(boot_top_k)) / k
                    stability_results['lime_feature_overlaps'].append(overlap)

                stability_results['bootstrap_iteration'].append(i)

            except Exception as e:
                print(f"Error in bootstrap iteration {i}: {e}")
                continue

        # Calculate stability statistics
        stability_stats = {}
        if stability_results['shap_kendall_taus']:
            shap_taus = np.array(stability_results['shap_kendall_taus'])
            stability_stats['shap'] = {
                'mean_kendall_tau': np.mean(shap_taus),
                'std_kendall_tau': np.std(shap_taus),
                'fraction_above_0.9': np.mean(shap_taus > 0.9),
                'mean_feature_overlap': np.mean(stability_results['shap_feature_overlaps'])
            }

        if stability_results['lime_kendall_taus']:
            lime_taus = np.array(stability_results['lime_kendall_taus'])
            stability_stats['lime'] = {
                'mean_kendall_tau': np.mean(lime_taus),
                'std_kendall_tau': np.std(lime_taus),
                'fraction_above_0.9': np.mean(lime_taus > 0.9),
                'mean_feature_overlap': np.mean(stability_results['lime_feature_overlaps'])
            }

        print("\n=== EXPLANATION STABILITY RESULTS ===")
        for method, stats in stability_stats.items():
            print(f"\n{method.upper()} Stability:")
            print(f"  Mean Kendall τ: {stats['mean_kendall_tau']:.3f} ± {stats['std_kendall_tau']:.3f}")
            print(f"  Fraction τ > 0.9: {stats['fraction_above_0.9']:.1%}")
            print(f"  Mean feature overlap: {stats['mean_feature_overlap']:.3f}")

        return stability_stats, stability_results

    def save_explanations(self, output_dir, dataset_name):
        """Save all explanation data"""
        os.makedirs(output_dir, exist_ok=True)

        explanations_path = os.path.join(output_dir, f"{dataset_name}_explanations.pkl")
        with open(explanations_path, 'wb') as f:
            pickle.dump(self.explanation_data, f)

        print(f"Explanations saved to {explanations_path}")
        return explanations_path

def generate_explanations_for_dataset(dataset_name, processed_data_path, models_path):
    """
    Complete explanation generation pipeline for a dataset
    """
    print(f"\n{'='*60}")
    print(f"GENERATING EXPLANATIONS FOR {dataset_name.upper()}")
    print(f"{'='*60}")

    # Load data
    print("Loading processed data...")
    df_processed = pd.read_csv(processed_data_path)
    X = df_processed.drop(columns=["TARGET"])
    y = df_processed["TARGET"]

    # Train-test split for explanation generation
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Initialize explanation generator
    explainer = ExplanationGenerator(random_state=42)

    # Load trained models
    model_types = explainer.load_trained_models(models_path)

    # Setup explainers
    explainer.setup_shap_explainers(X_train.head(1000), model_types)  # Use subset for background
    explainer.setup_lime_explainers(X_train, model_types)

    # Generate explanations for test set sample
    test_sample_size = min(500, len(X_test))
    X_test_sample = X_test.head(test_sample_size)

    print(f"\nGenerating explanations for {len(X_test_sample)} test samples...")

    # Focus on XGBoost (best performing model based on paper)
    primary_model = 'xgboost'

    if primary_model in model_types:
        # Generate SHAP explanations
        shap_values = explainer.generate_shap_explanations(X_test_sample, primary_model)

        # Generate LIME explanations (smaller sample due to computational cost)
        lime_sample_size = min(50, len(X_test_sample))
        lime_explanations, lime_scores = explainer.generate_lime_explanations(
            X_test_sample.head(lime_sample_size), primary_model
        )

        # Stability analysis
        stability_stats, stability_results = explainer.analyze_explanation_stability(
            X_train, y_train, primary_model, n_bootstrap=50
        )

    # Save explanations
    output_dir = "explainable-credit-scoring/explanation_generation"
    explanations_path = explainer.save_explanations(output_dir, dataset_name)

    print(f"\n✅ Explanation generation complete!")
    print(f"📁 Explanations saved to: {explanations_path}")

    return explainer

if __name__ == "__main__":
    # Example usage - can be run for any dataset
    dataset_configs = {
        'uci_credit_card': {
            'processed_data_path': "explainable-credit-scoring/data_preprocessing/uci_credit_card_processed_data_fold0.csv",
            'models_path': "explainable-credit-scoring/model_training/uci_credit_card_models.pkl"
        },
        'lending_club': {
            'processed_data_path': "explainable-credit-scoring/data_preprocessing/lending_club_processed_data_fold0.csv",
            'models_path': "explainable-credit-scoring/model_training/lending_club_models.pkl"
        },
        'home_credit': {
            'processed_data_path': "explainable-credit-scoring/data_preprocessing/home_credit_processed_data_fold0.csv",
            'models_path': "explainable-credit-scoring/model_training/home_credit_models.pkl"
        }
    }

    # Run for UCI Credit Card dataset as example
    dataset = 'uci_credit_card'
    config = dataset_configs[dataset]

    if os.path.exists(config['processed_data_path']) and os.path.exists(config['models_path']):
        explainer = generate_explanations_for_dataset(
            dataset, 
            config['processed_data_path'], 
            config['models_path']
        )
    else:
        print(f"Required files not found for {dataset}. Please run preprocessing and model training first.")
