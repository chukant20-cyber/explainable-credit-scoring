
import pandas as pd
import numpy as np
import pickle
import os
from sklearn.metrics import confusion_matrix, roc_curve, auc
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

class FairnessEvaluator:
    """
    Comprehensive fairness evaluation and constraint optimization
    Implements multiple fairness metrics and constrained threshold selection
    """

    def __init__(self, random_state=42):
        self.random_state = random_state
        self.fairness_results = {}
        self.optimal_thresholds = {}

    def load_model_predictions(self, models_path, X_test, model_type='xgboost'):
        """Load trained models and generate predictions"""
        print(f"Loading model predictions for {model_type}...")

        with open(models_path, 'rb') as f:
            model_data = pickle.load(f)

        models = model_data['models']
        calibrators = model_data['calibrators']
        scalers = model_data.get('scalers', {})

        if model_type not in models:
            raise ValueError(f"Model {model_type} not found in saved models")

        model = models[model_type]
        calibrator = calibrators[model_type]

        # Scale features if needed
        if model_type in scalers:
            X_test_scaled = scalers[model_type].transform(X_test)
        else:
            X_test_scaled = X_test

        # Get uncalibrated predictions
        if hasattr(model, 'predict_proba'):
            uncalibrated_probs = model.predict_proba(X_test_scaled)[:, 1]
        else:
            uncalibrated_probs = model.decision_function(X_test_scaled)

        # Apply calibration
        calibrated_probs = calibrator.transform(uncalibrated_probs)

        return calibrated_probs

    def calculate_fairness_metrics(self, y_true, y_pred, y_pred_proba, protected_attr, 
                                  privileged_group_value, threshold=0.5):
        """
        Calculate comprehensive fairness metrics
        """
        # Create binary predictions based on threshold
        y_pred_binary = (y_pred_proba >= threshold).astype(int)

        # Separate groups
        privileged_mask = (protected_attr == privileged_group_value)
        unprivileged_mask = ~privileged_mask

        # Basic group statistics
        n_privileged = privileged_mask.sum()
        n_unprivileged = unprivileged_mask.sum()

        if n_privileged == 0 or n_unprivileged == 0:
            print("Warning: One of the groups is empty. Cannot calculate fairness metrics.")
            return None

        # Group-specific metrics
        def group_metrics(mask):
            y_true_group = y_true[mask]
            y_pred_group = y_pred_binary[mask]
            y_prob_group = y_pred_proba[mask]

            if len(y_true_group) == 0:
                return None

            # Confusion matrix components
            tn, fp, fn, tp = confusion_matrix(y_true_group, y_pred_group).ravel()

            # Rates
            tpr = tp / (tp + fn) if (tp + fn) > 0 else 0  # True Positive Rate (Sensitivity)
            fpr = fp / (fp + tn) if (fp + tn) > 0 else 0  # False Positive Rate
            tnr = tn / (tn + fp) if (tn + fp) > 0 else 0  # True Negative Rate (Specificity)
            fnr = fn / (fn + tp) if (fn + tp) > 0 else 0  # False Negative Rate

            # Predictive values
            ppv = tp / (tp + fp) if (tp + fp) > 0 else 0  # Positive Predictive Value (Precision)
            npv = tn / (tn + fn) if (tn + fn) > 0 else 0  # Negative Predictive Value

            # Other metrics
            accuracy = (tp + tn) / (tp + tn + fp + fn)
            positive_rate = (y_pred_group == 1).mean()  # Selection rate
            base_rate = y_true_group.mean()  # Actual positive rate

            return {
                'n': len(y_true_group),
                'true_positive_rate': tpr,
                'false_positive_rate': fpr,
                'true_negative_rate': tnr,
                'false_negative_rate': fnr,
                'positive_predictive_value': ppv,
                'negative_predictive_value': npv,
                'accuracy': accuracy,
                'positive_rate': positive_rate,
                'base_rate': base_rate,
                'tp': tp, 'fp': fp, 'tn': tn, 'fn': fn
            }

        privileged_metrics = group_metrics(privileged_mask)
        unprivileged_metrics = group_metrics(unprivileged_mask)

        if privileged_metrics is None or unprivileged_metrics is None:
            return None

        # Calculate fairness metrics
        fairness_metrics = {
            'threshold': threshold,
            'privileged_group_size': n_privileged,
            'unprivileged_group_size': n_unprivileged,

            # Demographic Parity (Statistical Parity)
            'demographic_parity_diff': (unprivileged_metrics['positive_rate'] - 
                                      privileged_metrics['positive_rate']),

            # Equalized Odds (True Positive Rate parity)
            'equalized_odds_diff': (unprivileged_metrics['true_positive_rate'] - 
                                  privileged_metrics['true_positive_rate']),

            # Equalized Opportunity (False Positive Rate parity) 
            'equal_opportunity_diff': (unprivileged_metrics['false_positive_rate'] - 
                                     privileged_metrics['false_positive_rate']),

            # Average Odds Difference
            'average_odds_diff': (0.5 * abs(unprivileged_metrics['true_positive_rate'] - 
                                          privileged_metrics['true_positive_rate']) +
                                0.5 * abs(unprivileged_metrics['false_positive_rate'] - 
                                        privileged_metrics['false_positive_rate'])),

            # Predictive Parity (Precision parity)
            'predictive_parity_diff': (unprivileged_metrics['positive_predictive_value'] - 
                                     privileged_metrics['positive_predictive_value']),

            # Calibration within groups (simplified)
            'calibration_diff': abs(unprivileged_metrics['base_rate'] - privileged_metrics['base_rate']),

            # Individual group metrics
            'privileged_metrics': privileged_metrics,
            'unprivileged_metrics': unprivileged_metrics
        }

        return fairness_metrics

    def cost_aware_objective(self, threshold, y_true, y_pred_proba, protected_attr, 
                           privileged_group_value, loss_per_default=5000, 
                           opportunity_cost=500, fairness_constraint=0.05, 
                           fairness_penalty_weight=1000):
        """
        Cost-aware objective function with fairness constraints
        Implements the optimization from the research paper
        """
        # Generate predictions at this threshold
        y_pred = (y_pred_proba >= threshold).astype(int)

        # Calculate costs
        # Type I error: Approving a defaulter (False Negative)
        # Type II error: Rejecting a non-defaulter (False Positive)

        defaults_approved = np.sum((y_true == 1) & (y_pred == 1))  # True Positives
        good_rejected = np.sum((y_true == 0) & (y_pred == 0))      # True Negatives
        defaults_missed = np.sum((y_true == 1) & (y_pred == 0))    # False Negatives  
        good_approved = np.sum((y_true == 0) & (y_pred == 1))     # False Positives

        # Wait, I think there's confusion in the variable names above. Let me fix:
        # For credit scoring: 
        # - y_true = 1 means default (bad)
        # - y_pred = 1 means approve loan
        # So the cost structure should be:
        # - Approve a defaulter (y_true=1, y_pred=1): lose money = False Positive in traditional sense
        # - Reject a good customer (y_true=0, y_pred=0): opportunity cost = False Negative in traditional sense

        # Let me redefine more clearly:
        # For lending: y_pred = 1 means "approve", y_pred = 0 means "reject"
        # Cost occurs when: approve bad customer OR reject good customer

        approved_defaults = np.sum((y_true == 1) & (y_pred == 1))  # Bad customers approved
        rejected_goods = np.sum((y_true == 0) & (y_pred == 0))     # Good customers rejected

        total_cost = (approved_defaults * loss_per_default + 
                     rejected_goods * opportunity_cost)

        # Calculate fairness constraint violation
        fairness_metrics = self.calculate_fairness_metrics(
            y_true, y_pred, y_pred_proba, protected_attr, privileged_group_value, threshold
        )

        if fairness_metrics is None:
            return float('inf')

        # Use demographic parity as primary fairness constraint
        fairness_violation = max(0, abs(fairness_metrics['demographic_parity_diff']) - fairness_constraint)

        # Total objective: cost + fairness penalty
        objective = total_cost + fairness_penalty_weight * fairness_violation

        return objective

    def optimize_fair_threshold(self, y_true, y_pred_proba, protected_attr, 
                               privileged_group_value, loss_per_default=5000,
                               opportunity_cost=500, fairness_constraint=0.05):
        """
        Optimize threshold with fairness constraints
        Implements Hypothesis H3 testing from the research paper
        """
        print("Optimizing fair threshold...")
        print(f"Fairness constraint (demographic parity): ≤ {fairness_constraint}")
        print(f"Loss per default: ${loss_per_default}")
        print(f"Opportunity cost: ${opportunity_cost}")

        # Baseline performance (no fairness constraints)
        # Find threshold that minimizes cost without fairness constraints
        def cost_only_objective(threshold):
            return self.cost_aware_objective(
                threshold, y_true, y_pred_proba, protected_attr, 
                privileged_group_value, loss_per_default, opportunity_cost, 
                fairness_constraint=1.0, fairness_penalty_weight=0
            )

        # Optimize baseline
        result_baseline = minimize(
            cost_only_objective,
            x0=0.5,
            bounds=[(0.01, 0.99)],
            method='L-BFGS-B'
        )

        baseline_threshold = result_baseline.x[0]
        baseline_cost = result_baseline.fun
        baseline_fairness = self.calculate_fairness_metrics(
            y_true, (y_pred_proba >= baseline_threshold).astype(int), y_pred_proba,
            protected_attr, privileged_group_value, baseline_threshold
        )

        # Optimize with fairness constraints
        def fair_objective(threshold):
            return self.cost_aware_objective(
                threshold, y_true, y_pred_proba, protected_attr,
                privileged_group_value, loss_per_default, opportunity_cost,
                fairness_constraint=fairness_constraint, fairness_penalty_weight=10000
            )

        result_fair = minimize(
            fair_objective,
            x0=0.5,
            bounds=[(0.01, 0.99)],
            method='L-BFGS-B'
        )

        fair_threshold = result_fair.x[0]
        fair_cost_raw = self.cost_aware_objective(
            fair_threshold, y_true, y_pred_proba, protected_attr,
            privileged_group_value, loss_per_default, opportunity_cost,
            fairness_constraint=1.0, fairness_penalty_weight=0  # Get raw cost
        )

        fair_fairness = self.calculate_fairness_metrics(
            y_true, (y_pred_proba >= fair_threshold).astype(int), y_pred_proba,
            protected_attr, privileged_group_value, fair_threshold
        )

        # Calculate improvements
        cost_increase_pct = ((fair_cost_raw - baseline_cost) / baseline_cost) * 100

        if baseline_fairness and fair_fairness:
            baseline_gap = abs(baseline_fairness['demographic_parity_diff'])
            fair_gap = abs(fair_fairness['demographic_parity_diff'])
            fairness_improvement = ((baseline_gap - fair_gap) / baseline_gap) * 100 if baseline_gap > 0 else 0
        else:
            fairness_improvement = 0

        optimization_results = {
            'baseline_threshold': baseline_threshold,
            'baseline_cost': baseline_cost,
            'baseline_fairness_gap': baseline_gap if baseline_fairness else None,
            'fair_threshold': fair_threshold,
            'fair_cost': fair_cost_raw,
            'fair_fairness_gap': fair_gap if fair_fairness else None,
            'cost_increase_pct': cost_increase_pct,
            'fairness_improvement_pct': fairness_improvement,
            'baseline_metrics': baseline_fairness,
            'fair_metrics': fair_fairness
        }

        print("\n=== THRESHOLD OPTIMIZATION RESULTS ===")
        print(f"Baseline threshold: {baseline_threshold:.3f}")
        print(f"Fair threshold: {fair_threshold:.3f}")
        print(f"Cost increase: {cost_increase_pct:.1f}%")
        print(f"Fairness improvement: {fairness_improvement:.1f}%")
        if baseline_fairness and fair_fairness:
            print(f"Demographic parity gap: {baseline_gap:.3f} → {fair_gap:.3f}")

        return optimization_results

    def comprehensive_fairness_evaluation(self, y_true, y_pred_proba, protected_attrs_dict,
                                        models_path=None, dataset_name="unknown"):
        """
        Complete fairness evaluation across all available protected attributes
        """
        print(f"\n{'='*60}")
        print(f"COMPREHENSIVE FAIRNESS EVALUATION - {dataset_name.upper()}")
        print(f"{'='*60}")

        results = {}

        for attr_name, attr_config in protected_attrs_dict.items():
            print(f"\n--- Analyzing {attr_name} ---")

            protected_attr = attr_config['values']
            privileged_value = attr_config['privileged_value']

            # Skip if attribute has missing values or insufficient data
            if pd.isna(protected_attr).any():
                print(f"Warning: {attr_name} has missing values. Skipping...")
                continue

            unique_values = np.unique(protected_attr)
            if len(unique_values) < 2:
                print(f"Warning: {attr_name} has only one unique value. Skipping...")
                continue

            # Ensure minimum group sizes
            privileged_count = np.sum(protected_attr == privileged_value)
            unprivileged_count = len(protected_attr) - privileged_count

            if privileged_count < 100 or unprivileged_count < 100:
                print(f"Warning: Insufficient sample size for {attr_name}. Skipping...")
                continue

            print(f"Privileged group ({privileged_value}): {privileged_count}")
            print(f"Unprivileged group: {unprivileged_count}")

            # Baseline fairness analysis (threshold = 0.5)
            baseline_metrics = self.calculate_fairness_metrics(
                y_true, (y_pred_proba >= 0.5).astype(int), y_pred_proba,
                protected_attr, privileged_value, threshold=0.5
            )

            if baseline_metrics is None:
                print(f"Could not calculate baseline metrics for {attr_name}")
                continue

            # Threshold optimization with different fairness tolerances
            optimization_results = {}
            tolerance_levels = [0.01, 0.03, 0.05, 0.10]

            for tolerance in tolerance_levels:
                print(f"\nOptimizing with fairness tolerance = {tolerance}")

                opt_result = self.optimize_fair_threshold(
                    y_true, y_pred_proba, protected_attr, privileged_value,
                    fairness_constraint=tolerance
                )

                optimization_results[f'tolerance_{tolerance}'] = opt_result

            results[attr_name] = {
                'baseline_metrics': baseline_metrics,
                'optimization_results': optimization_results,
                'group_sizes': {
                    'privileged': privileged_count,
                    'unprivileged': unprivileged_count
                }
            }

        self.fairness_results[dataset_name] = results
        return results

    def generate_fairness_report(self, results, dataset_name):
        """Generate comprehensive fairness report"""
        print(f"\n{'='*80}")
        print(f"FAIRNESS EVALUATION REPORT - {dataset_name.upper()}")
        print(f"{'='*80}")

        for attr_name, attr_results in results.items():
            print(f"\n{'--- ' + attr_name.upper() + ' ---':^80}")

            baseline = attr_results['baseline_metrics']
            group_sizes = attr_results['group_sizes']

            print(f"Group sizes: Privileged={group_sizes['privileged']}, "
                  f"Unprivileged={group_sizes['unprivileged']}")

            print("\nBaseline Metrics (threshold=0.5):")
            print(f"  Demographic Parity Difference: {baseline['demographic_parity_diff']:.3f}")
            print(f"  Equalized Odds Difference: {baseline['equalized_odds_diff']:.3f}")
            print(f"  Equal Opportunity Difference: {baseline['equal_opportunity_diff']:.3f}")
            print(f"  Predictive Parity Difference: {baseline['predictive_parity_diff']:.3f}")

            print("\nThreshold Optimization Results:")
            print(f"{'Tolerance':<12} {'Cost Increase':<15} {'Fairness Reduction':<20} {'Final Gap':<12}")
            print("-" * 60)

            for tolerance_key, opt_result in attr_results['optimization_results'].items():
                tolerance = tolerance_key.split('_')[1]
                cost_inc = opt_result.get('cost_increase_pct', 0)
                fair_imp = opt_result.get('fairness_improvement_pct', 0)
                final_gap = opt_result.get('fair_fairness_gap', 0)

                print(f"{tolerance:<12} {cost_inc:>8.1f}%      {fair_imp:>10.1f}%          {final_gap:>8.3f}")

    def save_fairness_results(self, output_dir, dataset_name):
        """Save fairness evaluation results"""
        os.makedirs(output_dir, exist_ok=True)

        fairness_path = os.path.join(output_dir, f"{dataset_name}_fairness_evaluation.pkl")
        with open(fairness_path, 'wb') as f:
            pickle.dump(self.fairness_results, f)

        print(f"\nFairness results saved to {fairness_path}")
        return fairness_path

def evaluate_fairness_for_dataset(dataset_name, processed_data_path, models_path, 
                                protected_attrs_config):
    """
    Complete fairness evaluation pipeline for a dataset
    """
    print(f"\n{'='*60}")
    print(f"FAIRNESS EVALUATION FOR {dataset_name.upper()}")
    print(f"{'='*60}")

    # Load data
    print("Loading data...")
    df_processed = pd.read_csv(processed_data_path)
    X = df_processed.drop(columns=["TARGET"])
    y = df_processed["TARGET"]

    # Initialize fairness evaluator
    evaluator = FairnessEvaluator(random_state=42)

    # Get model predictions
    y_pred_proba = evaluator.load_model_predictions(models_path, X, model_type='xgboost')

    # Prepare protected attributes
    protected_attrs_dict = {}

    for attr_name, attr_config in protected_attrs_config.items():
        if attr_config['column'] in df_processed.columns:
            protected_attrs_dict[attr_name] = {
                'values': df_processed[attr_config['column']].values,
                'privileged_value': attr_config['privileged_value']
            }
            print(f"Found protected attribute: {attr_name}")
        else:
            print(f"Warning: {attr_config['column']} not found in data")

    if not protected_attrs_dict:
        print("No protected attributes found. Cannot perform fairness evaluation.")
        return None

    # Run comprehensive fairness evaluation
    results = evaluator.comprehensive_fairness_evaluation(
        y, y_pred_proba, protected_attrs_dict, models_path, dataset_name
    )

    # Generate report
    evaluator.generate_fairness_report(results, dataset_name)

    # Save results
    output_dir = "explainable-credit-scoring/fairness_evaluation"
    fairness_path = evaluator.save_fairness_results(output_dir, dataset_name)

    print(f"\n✅ Fairness evaluation complete!")
    return evaluator, results

if __name__ == "__main__":
    # Example protected attributes configuration
    protected_attrs_configs = {
        'home_credit': {
            'gender': {
                'column': 'CODE_GENDER_F',  # Assuming one-hot encoded
                'privileged_value': 0  # Male (0 when female is 1)
            },
            'age': {
                'column': 'AGE_GROUP',  # Would need to create age groups
                'privileged_value': 'middle_age'
            }
        },
        'uci_credit_card': {
            'gender': {
                'column': 'SEX',
                'privileged_value': 1  # Male
            },
            'age': {
                'column': 'AGE_GROUP',
                'privileged_value': 'middle_age'
            }
        },
        'lending_club': {
            'income': {
                'column': 'INCOME_GROUP',  # Income-based proxy
                'privileged_value': 'high_income'
            }
        }
    }

    # Example usage
    dataset = 'uci_credit_card'
    if dataset in protected_attrs_configs:
        processed_data_path = f"explainable-credit-scoring/data_preprocessing/{dataset}_processed_data_fold0.csv"
        models_path = f"explainable-credit-scoring/model_training/{dataset}_models.pkl"

        if os.path.exists(processed_data_path) and os.path.exists(models_path):
            evaluator, results = evaluate_fairness_for_dataset(
                dataset, processed_data_path, models_path, 
                protected_attrs_configs[dataset]
            )
        else:
            print("Required files not found. Please run preprocessing and model training first.")
