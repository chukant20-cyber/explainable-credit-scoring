
import pandas as pd
import numpy as np
import pickle
import os
from sklearn.model_selection import train_test_split
from explainable_credit_scoring_model import ExplainableCreditScoringModel
import warnings
warnings.filterwarnings('ignore')

def train_uci_credit_card_models(processed_data_path, random_state=42):
    """
    Train all model types for UCI Credit Card dataset
    Implements the methodology from the research paper
    """
    print("=== UCI CREDIT CARD MODEL TRAINING ===\n")

    if not os.path.exists(processed_data_path):
        print(f"Error: Processed data not found at {processed_data_path}")
        print("Please run data preprocessing first.")
        return None

    # Load preprocessed data
    print("Loading preprocessed data...")
    df_processed = pd.read_csv(processed_data_path)

    # Separate features and target
    X = df_processed.drop(columns=["TARGET"])
    y = df_processed["TARGET"]

    print(f"Dataset shape: {X.shape}")
    print(f"Default rate: {y.mean():.1%}")
    print(f"Features: {X.columns.tolist()[:10]}..." if len(X.columns) > 10 else f"Features: {X.columns.tolist()}")

    # Train-test split (80-20) with stratification
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_state, stratify=y
    )

    print(f"\nTrain set: {X_train.shape[0]} samples")
    print(f"Test set: {X_test.shape[0]} samples")
    print(f"Train default rate: {y_train.mean():.1%}")
    print(f"Test default rate: {y_test.mean():.1%}")

    # Initialize model trainer
    model_trainer = ExplainableCreditScoringModel(random_state=random_state)

    # Train all models
    print("\n" + "="*50)
    print("TRAINING ALL MODEL TYPES")
    print("="*50)

    results = model_trainer.train_all_models(X_train, y_train, X_test, y_test)

    # Display results summary
    print("\n" + "="*50)
    print("RESULTS SUMMARY")
    print("="*50)

    summary_data = []
    for model_type, result in results.items():
        if 'error' not in result:
            summary_data.append({
                'Model': model_type.replace('_', ' ').title(),
                'CV_AUC': result['cv_score'],
                'Test_AUC': result['test_metrics']['auc'],
                'Test_Accuracy': result['test_metrics']['accuracy'],
                'Brier_Score': result['test_metrics']['brier_score'],
                'ECE': result['test_metrics']['ece'],
                'MCE': result['test_metrics']['mce']
            })

    summary_df = pd.DataFrame(summary_data)
    print(summary_df.to_string(index=False, float_format='%.4f'))

    # Save models and results
    output_dir = "explainable-credit-scoring/model_training"
    os.makedirs(output_dir, exist_ok=True)

    models_path, perf_path = model_trainer.save_models(output_dir, "uci_credit_card")

    print(f"\n✅ All models trained and saved successfully!")
    print(f"📁 Models: {models_path}")
    print(f"📊 Performance: {perf_path}")

    return model_trainer, results

if __name__ == "__main__":
    processed_data_path = "explainable-credit-scoring/data_preprocessing/uci_credit_card_processed_data_fold0.csv"
    trainer, results = train_uci_credit_card_models(processed_data_path)
